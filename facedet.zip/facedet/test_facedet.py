import unittest
import facedet
from facedet import faceext

class TestFace(unittest.TestCase):
  
  def test_detection():
   assert image is not None,"Image not found!"

if __name__ == '__main__':
 unittest.main()
